Place card images here:

  First album (Safari):
    card_01.png, card_02.png, ... card_08.png

  Second album (Fantasy):
    safari_0.png, safari_1.png, ... safari_7.png

Use PNG or WebP; keep the numbering. The game will use these for the Collection albums.
